export class Resp {
  success: boolean;
  message: string;
  data: any;
  count: number;
}
