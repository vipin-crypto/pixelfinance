export class Products {
  images: any;
  _id: string;
  category: any;
  subCategory: any;
  price: number;
  topDeals: boolean;
  isRecommended: boolean;
  name: string;
  brand: any;
  discount: number;
  productQuantity: number;
  purchaseQuantity: number;
  condition: string;
  extraPrice: number;
  description: string;
  createdAt: string;
  updatedAt: string;
}
