export class Banner {
  _id: string;
  name: string;
  discount: number;
  type: string;
  coupon: any;
  image: string;
  createdAt: string;
  isActive: boolean;
  updatedAt: string;
}
