export class Brand {
  _id: string;
  name: string;
  image: string;
  createdAt: string;
  updatedAt: string;
}
