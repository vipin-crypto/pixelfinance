export class Driver {
  profileStatus: string;
  _id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  address: string;
  bio: string;
  city: string;
  isApproved: boolean;
  createdAt: string;
  updatedAt: string;
  documents: any;
  id: string;
}
