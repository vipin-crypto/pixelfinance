export class SubCategories {
  _id: string;
  name: string;
  image: string;
  category: any;
  subCategory: any;
  createdAt: string;
  updatedAt: string;
}
