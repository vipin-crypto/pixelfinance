export class AddSubCategoryBody {
  name: string;
  category: string;
  discount: any;
  isUpto: boolean = false;
  type: string = "";
  image: any;
  id: string;
}
