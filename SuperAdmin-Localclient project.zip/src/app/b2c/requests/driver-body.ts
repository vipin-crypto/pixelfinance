export class DriverBody {
  firstName: string;
  lastName: string;
  email: string;
  password: string;
  phone: string;
  city: string;
  street: string;
  country: string;
  state: string;
  pinCode: string;
  address: any;
  bio: string;
  id: string;
}
