export class AddUserBody {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  // userName: string;
  phone: string;
  countryCode: string;
  // state: string;
  // city: string;
  // address: string;
  // password: string;
  // role: string = 'SELLER';
}
