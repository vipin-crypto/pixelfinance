export class VendorBody{
    id:String;
    name:String;
    email:String;
    fence:string='';
    password:String;
    bio:String;
    address:string;
    category:string='';
    businessDetail:String;
    // latitude:any;
    // longitude:any;
}