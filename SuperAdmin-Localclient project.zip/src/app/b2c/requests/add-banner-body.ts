export class AddBannerBody {
  name: string;
  image: any;
  type: string;
  coupon: string;
  discountType: string = '';
  discount: string;
  country=["india"]
  offer: any;
  id: string;
}
