import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/commonservice/api.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  role:any;
  access:any;
  constructor(private auth: ApiService) { }

  ngOnInit() {
    this.role=JSON.parse(localStorage.getItem('Dayfresh_Admin'));
    this.access=JSON.parse(localStorage.getItem('permission'));
  }

   
}
