import { Component,NgZone, OnInit } from '@angular/core';
import { ApiService } from '../../services/api.service';
import * as FusionCharts from "fusioncharts";



@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  totalOrder: any;
  totalUser: any;
  totalBanner: any;
  totalCategory: any;
  totalSubcategory: any;
  totalProduct: any;
  dashData: any;
  dataSource:any;
  type: string;
  width: string;
  height: string;
  dataFormat = "json";
  areaData:any;
  saleData:any;
  role:any;
  access:any;
count:any;
  admin_bussi: any;
  admin_id: any;
  Adminlist: any;
  superlist: any;
  constructor(private api: ApiService) {
  
   }

  ngOnInit() 
  {

  }

 


}
