import { Component, OnInit } from '@angular/core';
import { AddUserBody } from "../../../requests/add-user-body";
import { ActivatedRoute, Router } from "@angular/router";
import { Resp } from "../../../models/Resp";
import { ToastrManager } from 'ng6-toastr-notifications';
import { ApiService } from 'src/app/b2c/services/api.service';
import base from 'src/app/b2c/services/api.service';
import countryCode from '../../../requests/countrycode';

@Component({
  selector: 'app-edit-user',
  templateUrl: './edit-user.component.html',
  styleUrls: ['./edit-user.component.scss']
})

export class EditUserComponent implements OnInit {
  history = window.history;
  body = new AddUserBody();
  userId: string;
  codes = [];
  defaultImage = "assets/img/defaultuser.jpg";
  countryCode: any;
  flags = {
    isUpdate: false
  };
  src: any;
  file: File;
  imageUrl = base;
  formData = new FormData();

  singleDropDownSetting: any = {
    enableCheckAll: false,
    singleSelection: true,
    idField: 'item_id',
    textField: 'item_text',
    selectAllText: 'Select All',
    unSelectAllText: 'UnSelect All',
    itemsShowLimit: 1,
    allowSearchFilter: true
  };

  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private api: ApiService,
    private toaster: ToastrManager
  ) { }

  ngOnInit() {
    this.codes = countryCode;
    // countryCode.forEach(ele => {
    //   this.codes.push({ item_id: ele.name, item_text: ele.dial_code })
    // })

    this.activatedRoute.params.subscribe((param: any) => {
      this.userId = param.id;
      this.getUserDetail();
    });
  }
  getUserDetail() {
    this.api.getUserDetail(this.userId).subscribe((response: Resp) => {
      // console.log(response);
      if (!response.success) return;
      this.body = response.data;
      this.userId = response.data._id;
      this.countryCode = this.body.countryCode;
      this.src = response.data.profile
      // this.src = `${this.imageUrl}${response.data.profile}`;
    });
  }

  onImageSelect(e) {
    const file = e.target.files[0];
    this.formData.delete('image');
    if (file.type == 'image/png' || file.type == 'image/jpg' || file.type == 'image/jpeg') {
      const reader = new FileReader();
      reader.onload = (event: any) => {
        this.src = event.target.result;
      };
      reader.readAsDataURL(e.target.files[0]);
      this.file = file;
      this.formData.append('image', this.file);
    } else {
      this.errorToast('Selected file is not image.');
    }
  }

  editUser() {
    // console.log("cc", this.countryCode);
    if(this.body.firstName.trim()=="") return this.errorToast('Please enter First Name')
    if(this.body.lastName.trim()=="") return this.errorToast('Please enter Last Name')

    this.flags.isUpdate = true;
    this.formData.append('firstName', this.body.firstName)
    this.formData.append('lastName', this.body.lastName)
    this.formData.append('email', this.body.email)
    this.formData.append('countryCode', this.countryCode)
    this.formData.append('phone', this.body.phone)
    this.formData.append('id', this.userId)

    this.api.updateUser(this.formData).subscribe((response: Resp) => {
      this.flags.isUpdate = false;
      if (!response.success) return this.errorToast(response.message);
      this.successToast('User updated successfully!')

    }, error => {
      this.flags.isUpdate = false;
    });
  }

  successToast(message) {
    this.toaster.successToastr(message, '', {
      maxShown: 1
    });
  }

  errorToast(message) {
    this.toaster.errorToastr(message);
  }

}
