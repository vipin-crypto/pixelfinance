import { Component, OnInit } from '@angular/core';

import { AddUserBody } from '../../../requests/add-user-body';
import { Router } from "@angular/router";

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.scss']
})
export class AddUserComponent implements OnInit {
  history = window.history;
  body = new AddUserBody();
  flags = {
    isAdded: false
  };

  constructor(
    private router: Router
  ) { }

  ngOnInit() {
  }
}
