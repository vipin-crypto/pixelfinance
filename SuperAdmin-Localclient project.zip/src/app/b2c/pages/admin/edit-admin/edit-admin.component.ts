import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-admin',
  templateUrl: './edit-admin.component.html',
  styleUrls: ['./edit-admin.component.scss']
})
export class EditAdminComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
