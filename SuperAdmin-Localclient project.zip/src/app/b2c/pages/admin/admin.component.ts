import { Component, OnInit, ViewChild } from '@angular/core';
import { ApiService } from '../../services/api.service';
import base from '../../services/api.service';
import Swal from 'sweetalert2';
import { ToastrManager } from 'ng6-toastr-notifications';
import { ThemePalette } from '@angular/material/core';
import { saveAs } from 'file-saver';
import { AdminModalComponent } from './admin-modal/admin-modal.component';
 
@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.scss']
})
export class AdminComponent implements OnInit 
{
  @ViewChild(AdminModalComponent, { static: false }) modal: AdminModalComponent;
  delAddress:any;
  currentPage: number;
  subAdminList: any;
  totalItems: any;
  serialNumber = 0;
  loading: boolean = false;       //if loader required we can use it.
  color: ThemePalette = 'primary';
  imageUrl = base;
  defaultImage = "assets/img/defaultuser.jpg";
  selectSubAdmin: any = '';
  fenceList:any;
   superlist:any;
  

  constructor(private api: ApiService, private toaster: ToastrManager) {  this.superlist = JSON.parse(localStorage.getItem('Dayfresh_Admin'))._id}

  ngOnInit() {

  
   
  }

 
}
