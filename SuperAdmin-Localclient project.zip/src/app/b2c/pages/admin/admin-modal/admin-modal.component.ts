import { Component, OnInit, Input, Output, EventEmitter,ViewChild, ElementRef, NgZone} from '@angular/core';
 import { ApiService } from 'src/app/b2c/services/api.service';
import { Resp } from 'src/app/models/Resp';
import base from '../../../services/api.service'
import { AdminBody } from 'src/app/b2c/requests/sub-admin-body';
import { ToastrManager } from 'ng6-toastr-notifications';
import { MapsAPILoader } from '@agm/core';
declare var $: any;
declare var google:any
@Component({
  selector: 'app-admin-modal',
  templateUrl: './admin-modal.component.html',
  styleUrls: ['./admin-modal.component.scss']
})
export class AdminModalComponent implements OnInit {


  @Output() onAddEdit = new EventEmitter();
  body=new AdminBody();
  imageUrl = base;
  
  country: any = "india"
  formData = new FormData();
  latitude:any;
  longitude:any;
  zoom: any=15;
  selectedMarker: { lat: any; lng: any; };
  markers:any=[];
  address: string;

  private geoCoder;
  flags = {
    isAdded: false,
    isUpdate: false,
    isEdit: false
  };
  // tokenVal;

  @ViewChild('search',{static: false})
  public searchElementRef: ElementRef;
  superlist: any;


  constructor(private api: ApiService, private toaster: ToastrManager,
    private mapsAPILoader: MapsAPILoader,
    private ngZone: NgZone,) { }

  ngOnInit() {
    this.superlist = JSON.parse(localStorage.getItem('Dayfresh_Admin'))._id
    this.mapsAPILoader.load().then(() => {
      this.setCurrentLocation();
      this.geoCoder = new google.maps.Geocoder;
 
      let autocomplete = new google.maps.places.Autocomplete(this.searchElementRef.nativeElement, {
        types: ["address"]
      });
      autocomplete.addListener("place_changed", () => {
        this.ngZone.run(() => {
          
          let place: any= autocomplete.getPlace();
          
          if (place.geometry === undefined || place.geometry === null) {
            return;
          }
          
          this.latitude = place.geometry.location.lat();
          this.longitude = place.geometry.location.lng();
          this.zoom = 15;
          this.getAddress(this.latitude,this.longitude);
        });
      });
    });
  }


  private setCurrentLocation() {
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition((position) => {
        console.log(position)
        this.body.latitude = position.coords.latitude;
        this.body.longitude = position.coords.longitude;
        this.zoom = 15;
        this.getAddress(this.body.latitude, this.body.longitude);
      });
    }
  }

  editSubAdmin() {  
    if(this.body.latitude==null) return this.errorToast('Please select valid address');
    this.flags.isUpdate = true;
    this.api.updateAdmin(this.body).subscribe((response: Resp) => {
      this.flags.isUpdate = false;
      if (!response.success) {
        return this.errorToast(response.message);
      }
      this.successToast('Admin updated successfully!');
      this.onAddEdit.emit(true);
      this.onCancel();
    }, error => {
      this.flags.isUpdate = false;
    });
  }


  getAddress(latitude, longitude) {
    this.geoCoder.geocode({ 'location': { lat: latitude, lng: longitude } }, (results, status) => {
      // console.log(results);
      // console.log(status);
      if (status === 'OK') {
        if (results[0]) {
          this.zoom = 15;
          this.body.address = results[0].formatted_address;
        } else {
          window.alert('No results found');
        }
      } else {
        window.alert('Geocoder failed due to: ' + status);
      }
 
    });
  }

  onEditSelect(data) {
    console.log(data);
    this.flags.isEdit=true;
    this.body.name=data.name;
    this.body.email=data.email;
    this.body.password = data.password;
    this.body.address = data.address;
    // this.body.businessOwnerId = data.businessOwnerId
    this.body.id = data.id;
    this.getAddress(this.body.latitude,this.body.longitude)
    document.getElementById('openSubAdminModal').click();
  }

  addSubAdmin()
  {
    this.body.superAdminId = this.superlist
    this.api.addAdmin(this.body).subscribe((response:any)=>
    {
       this.flags.isAdded = false;
      if (!response.success) {
        return this.errorToast(response.message);
      }
      this.successToast('Admin added successfully!');
      this.onAddEdit.emit();
      this.onCancel();
    }, error => {
      this.flags.isAdded = false;
    });
  }

  onCancel() {
    this.flags.isEdit = false;
    this.body=new AdminBody();
    document.getElementById('closeSubAdminModal').click();
  }
  error = message => {
    this.errorToast(message);
  }

  successToast(message) {
    this.toaster.successToastr(message, '', {
      maxShown: 1
    });
  }

  errorToast(message) {
    this.toaster.errorToastr(message);
  }
}
