import { Component, OnInit } from '@angular/core';

import { FilterBody } from '../../../requests/filter-body';
import { Orders } from 'src/app/models/Orders';
import { Driver } from 'src/app/models/driver';
import { Resp } from 'src/app/models/Resp';
import { ApiService } from 'src/app/b2c/services/api.service';
import base from 'src/app/b2c/services/api.service';
import { ToastrManager } from 'ng6-toastr-notifications';
import { saveAs } from 'file-saver';
import { ThemePalette } from '@angular/material/core';
import * as moment from 'moment';


@Component({
  selector: 'app-new-order-list',
  templateUrl: './new-order-list.component.html',
  styleUrls: ['./new-order-list.component.scss']
})
export class NewOrderListComponent implements OnInit {
  url=base;
  totalItems: number;
  currentPage = 1;
  serialNumber = 0;
  status = '';
  filterBody = new FilterBody();
  selectedAddress: any;
  selectedProduct: Array<any> = [];
  requestId: string;
  newOrderList: Array<Orders> = [];
  selectedDriver: any;
  driverList: Array<Driver> = [];
  loading: boolean = true;
  selectOrder:any=''
  color: ThemePalette = 'primary';
  todayDate:any=moment().format('MMMM Do YYYY');
  tommorrowDate:any;
  tokenVal;
  allCreatedDate:any=[];
  role:any;
  access:any;
  adminId:any;
  totalAmount:any=[];
  timeSlotList: any;
  geofenceList: any;
  fence='';
  timeSloat='';   


  constructor(
    private api: ApiService, private toaster: ToastrManager
  ) {
     
   }

  ngOnInit() {
    this.role=JSON.parse(localStorage.getItem('Dayfresh_Admin'));
    this.access=JSON.parse(localStorage.getItem('permission'));
    this.adminId=this.role._id;
    var d = new Date()
    let tommorrow=d.setDate(d.getDate() + 1);
    this.tommorrowDate= moment(tommorrow).format('MMMM Do YYYY');
    

    this.getNewOrder();
    this.getAllOrders();
    this.getAllGeofence();
    this.getAllTimeSlot();
    // this.getDrivers();
  }

  getAllOrders() {
    this.allCreatedDate=[];
    let data={
       status: this.status,
        page: this.currentPage,
        search:this.selectOrder,
        userType:this.role.type,
        adminId:this.adminId,
        timesloat:this.timeSloat,
        fence:this.fence
      }
    this.api.getAllOrders(data).subscribe((response: any) => {
      // console.log(response);
    
      if (!response.success) return;
      this.newOrderList = response.data;
      this.loading=false;
      // console.log("order list"+JSON.stringify(this.orderList[0].products));
      this.totalItems = response.count;
      
      for(let i=0;i<this.newOrderList.length;i++){
        let d=moment(this.newOrderList[i].createdAt).format('MMMM Do YYYY');
       this.allCreatedDate.push(d);    
      } 
    
       
     });
  }
  setClass(list: Array<any>) {
    return list.findIndex(o => o.status == 'New');
  }

  getFilterOrder(){
    this.currentPage=1;
    this.loading=true;
    this.getAllOrders();
  }

  geneateInvoice(id){
    this.api.generateInvoice(id).subscribe((response:any)=>{
      if(!response.success) this.errorToast(response.message)
      saveAs(`${this.url}/${response.data}`,"invoice.pdf")
      // this.successToast(response.message);
    })
  }

  getNewOrder(){ 
   this.api.newOrder().subscribe((response:any)=>{
     console.log("new order",response)
     if(response.success) return this.successToast(response.message)
   }) ;
  }

  getAllGeofence(){
    this.api.getAllGeofencingList().subscribe((response:any)=>{
      this.geofenceList=response.data
    })
  }

  getAllTimeSlot(){
    this.api.getAllTimeSlot().subscribe((response:any)=>{
      this.timeSlotList=response.data
    })
  }

  processOrder(transactionId,status){
    let data={
      transactionId,
      status
    }
    this.api.acceptTransaction(data).subscribe((response:any)=>{
      if(!response.success) return this.errorToast(response.message);
      this.successToast1('Order accepted successfully');
      this.getAllOrders();
    })
  }

  

  addOneDay(date){
    // console.log(date)
    var nextDay = moment(date).add(1, 'days').format('MMMM Do YYYY');
    // console.log(nextDay);
    return nextDay;
  }
  // getDrivers() {
  //   this.api.getAllDriverWithoutPagination().subscribe((response: Resp) => {
  //     if (!response.success) return;
  //     this.driverList = response.data;
  //   });
  // }
  onSelectProduct(product: any) {
    // console.log(product);
    this.selectedProduct = product;
    
  }

  searchOrder(){
    this.selectOrder=this.selectOrder.trim();
    this.getAllOrders();
  }

  resetOrder(){
    this.selectOrder='';
    this.currentPage=1;
    this.getAllOrders();
  }

  setGeofenceId(geofence){
    this.api.setGeofenceId(geofence);
  }
  // processOrder(id: string, state: string, index: number) {
  //   // if (this.orderList[index].status == 'Packing' && !this.orderList[index].driver) return this.error('Please assign driver first.');
  //   this.api.processOrder(id, {status: state}).subscribe((response: Resp) => {
  //     if (!response.success) return;
  //     this.successToast(`Order ${state} successfully!`);
  //     this.orderList[index].status = response.data.status;
  //   });
  // }
  

  pageChange(page) {
    this.currentPage = page.page;
    this.serialNumber = 10 * this.currentPage - 10
    this.getAllOrders();
  }


  successToast(message) {
    this.toaster.infoToastr(message, '', {
      dismiss:'click'
    });
  }

  successToast1(message) {
    this.toaster.successToastr(message, '', {
      maxShown: 1
    });
  }

  errorToast(message) {
    this.toaster.errorToastr(message);
  }

   

}
