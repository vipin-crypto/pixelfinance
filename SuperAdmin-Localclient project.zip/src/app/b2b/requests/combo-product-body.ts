export class ComboProductBody {
  index: any = '';
  discount: number;
}
