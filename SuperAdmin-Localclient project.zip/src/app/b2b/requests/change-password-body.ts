export class ChangePasswordBody {
  password: string;
  newPassword: string;
  confirmPassword: string;
}
