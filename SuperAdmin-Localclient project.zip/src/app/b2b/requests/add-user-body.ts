export class AddUserBody {
  firstName: string;
  lastName: string;
  email: string;
  userName: string;
  phone: string;
  country: string;
  state: string;
  city: string;
  address: string;
  password: string;
  role: string = 'SELLER';
}
