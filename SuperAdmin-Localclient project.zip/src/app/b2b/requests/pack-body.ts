export class PackBody {
    id:String;
    productId: string;
    quantity: number;
    price: number;
    unit: string = "";
    packQuantity: number;
  
    maxPurchaseQty:number;
    minPurchaseQty: number;
    _id:string;
}