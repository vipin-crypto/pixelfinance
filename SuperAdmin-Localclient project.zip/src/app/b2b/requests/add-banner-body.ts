export class AddBannerBody {
  name: string;
  type: string;
  coupon: string;
  discount: number;
  offer: any;
  id: string;
}
