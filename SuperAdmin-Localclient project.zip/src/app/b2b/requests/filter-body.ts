export class FilterBody {
  limit: number = 10;
  page: number = 0;
  searchText: string;
  category: string;
  role: string;
  status: any;
  subCategory: string;
}
