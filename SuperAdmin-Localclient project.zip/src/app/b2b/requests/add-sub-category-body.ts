export class AddSubCategoryBody {
  name: string;
  category: string;
  id: string;
}
