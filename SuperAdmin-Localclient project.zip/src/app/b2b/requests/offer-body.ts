export class OfferBody {
  title: string;
  offer: any;
  id: string;
}
