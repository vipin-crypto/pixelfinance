export class AddHomeDataSettingBody {
  label: string;
  serialNumber: number;
}
