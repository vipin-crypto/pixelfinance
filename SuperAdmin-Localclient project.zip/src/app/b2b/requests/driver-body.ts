export class DriverBody {
  firstName: string;
  lastName: string;
  email: string;
  password: string;
  phone: string;
  city: string;
  address: string;
  bio: string;
  id: string;
}
