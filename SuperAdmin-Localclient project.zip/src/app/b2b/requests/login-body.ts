export class LoginBody {
  email: string;
  password: string;
  type: string = 'b2c';
}
