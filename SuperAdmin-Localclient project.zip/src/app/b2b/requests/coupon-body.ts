export class CouponBody {
  name: string;
  discount: string;
  type: string = '';
  category: string = '';
  startDate: string;
  endDate: string;
  description: string;
  id: string;
}
